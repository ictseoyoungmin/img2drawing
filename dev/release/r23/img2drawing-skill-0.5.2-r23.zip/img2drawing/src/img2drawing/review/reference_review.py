from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from ..reference import StageReferenceView
from .artifact import DrawingArtifact
from .comparison import labeled_multi_way, side_by_side, split_compare, crop_registered_overlay, crop_registered_absdiff


@dataclass(frozen=True)
class ReferenceReviewArtifacts:
    stage: str
    drawing: DrawingArtifact
    subject_reference: Path
    task_stage_target: Path | None
    authority_order: tuple[str, ...]
    subject_vs_drawing: Path
    subject_split: Path
    subject_drawing_overlay: Path
    subject_drawing_absdiff: Path
    task_target_vs_drawing: Path | None
    task_target_split: Path | None
    overview: Path

    # 0.5.1 compatibility names.
    @property
    def three_way(self) -> Path:
        # When a task target exists this property intentionally points at
        # the 4-way authority board; callers should prefer `overview`.
        return self.overview

    @property
    def has_task_stage_target(self) -> bool:
        return self.task_stage_target is not None

    def to_dict(self) -> dict:
        return {
            "schema":"img2drawing.reference_review_artifacts.v2",
            "stage":self.stage,
            "drawing":self.drawing.to_dict(),
            "authority_order":list(self.authority_order),
            "subject_reference":str(self.subject_reference),
            "task_stage_target":None if self.task_stage_target is None else str(self.task_stage_target),
            "subject_vs_drawing":str(self.subject_vs_drawing),
            "subject_split":str(self.subject_split),
            "subject_drawing_overlay":str(self.subject_drawing_overlay),
            "subject_drawing_absdiff":str(self.subject_drawing_absdiff),
            "task_target_vs_drawing":None if self.task_target_vs_drawing is None else str(self.task_target_vs_drawing),
            "task_target_split":None if self.task_target_split is None else str(self.task_target_split),
            "overview":str(self.overview),
            "three_way":str(self.overview),
        }


def build_reference_review(
    *,
    stage: str,
    drawing: DrawingArtifact,
    references: StageReferenceView,
    out_dir: str | Path,
) -> ReferenceReviewArtifacts:
    if references.stage_id != stage:
        raise ValueError(
            f"reference stage mismatch: {references.stage_id!r} != {stage!r}"
        )
    out=Path(out_dir)
    out.mkdir(parents=True,exist_ok=True)

    subject=references.subject.path
    task=None if references.task_stage_target is None else references.task_stage_target.path

    subject_vs=side_by_side(
        subject,drawing.path,out/"subject_vs_drawing.png",
        left_label="SUBJECT / GEOMETRY TRUTH",
        right_label="DRAWING",
    )
    subject_split=split_compare(subject,drawing.path,out/"subject_split.png")
    subject_overlay=crop_registered_overlay(subject,drawing.path,out/"subject_drawing_overlay.png")
    subject_absdiff=crop_registered_absdiff(subject,drawing.path,out/"subject_drawing_absdiff.png")

    task_vs=None
    task_split=None
    if task is not None:
        task_vs=side_by_side(
            task,drawing.path,out/"task_target_vs_drawing.png",
            left_label="TASK STAGE TARGET / SAME-TASK TRUTH",
            right_label="DRAWING",
        )
        task_split=split_compare(task,drawing.path,out/"task_target_split.png")
        overview=labeled_multi_way(
            [
                ("TASK TARGET / highest stage authority",task),
                ("SUBJECT / geometry truth",subject),
                ("CURRENT DRAWING",drawing.path),
            ],
            out/"reference_authority_overview.png",
        )
    else:
        overview=labeled_multi_way(
            [
                ("SUBJECT / geometry truth",subject),
                ("CURRENT DRAWING",drawing.path),
            ],
            out/"reference_authority_overview.png",
        )

    return ReferenceReviewArtifacts(
        stage=stage,
        drawing=drawing,
        subject_reference=subject,
        task_stage_target=task,
        authority_order=references.authority_order,
        subject_vs_drawing=subject_vs,
        subject_split=subject_split,
        subject_drawing_overlay=subject_overlay,
        subject_drawing_absdiff=subject_absdiff,
        task_target_vs_drawing=task_vs,
        task_target_split=task_split,
        overview=overview,
    )
